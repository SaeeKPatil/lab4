<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $isbn_no = $_POST['isbn_no'];
    $book_title = $_POST['book_title'];
    $author_name = $_POST['author_name'];
    $publisher_name = $_POST['publisher_name'];

    $stmt = $conn->prepare("INSERT INTO books (isbn_no, book_title, author_name, publisher_name) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $isbn_no, $book_title, $author_name, $publisher_name);

    if ($stmt->execute()) {
        echo "Book details inserted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    ISBN No: <input type="number" name="isbn_no" required><br>
    Book Title: <input type="text" name="book_title" required><br>
    Author Name: <input type="text" name="author_name" required><br>
    Publisher Name: <input type="text" name="publisher_name" required><br>
    <input type="submit" value="Insert Book">
</form>
