<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $isbn_no = $_POST['isbn_no'];

    $stmt = $conn->prepare("DELETE FROM books WHERE isbn_no = ?");
    $stmt->bind_param("i", $isbn_no);

    if ($stmt->execute()) {
        echo "Book record deleted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    ISBN No: <input type="number" name="isbn_no" required><br>
    <input type="submit" value="Delete Book">
</form>
