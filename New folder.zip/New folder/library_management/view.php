<?php
include 'db.php';

$sql = "SELECT book_title, isbn_no, author_name, publisher_name FROM books";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Book Title</th><th>ISBN No</th><th>Author Name</th><th>Publisher Name</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["book_title"] . "</td><td>" . $row["isbn_no"] . "</td><td>" . $row["author_name"] . "</td><td>" . $row["publisher_name"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No books found";
}

$conn->close();
?>
