<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $isbn_no = $_POST['isbn_no'];
    $book_title = $_POST['book_title'];
    $author_name = $_POST['author_name'];
    $publisher_name = $_POST['publisher_name'];

    $stmt = $conn->prepare("UPDATE books SET book_title = ?, author_name = ?, publisher_name = ? WHERE isbn_no = ?");
    $stmt->bind_param("sssi", $book_title, $author_name, $publisher_name, $isbn_no);

    if ($stmt->execute()) {
        echo "Book details updated successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    ISBN No: <input type="number" name="isbn_no" required><br>
    Book Title: <input type="text" name="book_title"><br>
    Author Name: <input type="text" name="author_name"><br>
    Publisher Name: <input type="text" name="publisher_name"><br>
    <input type="submit" value="Update Book">
</form>
