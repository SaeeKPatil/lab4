<?php
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_id = $_POST['emp_id'];

    $stmt = $conn->prepare("DELETE FROM employee WHERE emp_id = ?");
    $stmt->bind_param("i", $emp_id); 

    if ($stmt->execute()) {
        echo "Employee record deleted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Employee ID: <input type="number" name="emp_id" required><br>
    <input type="submit" value="Delete">
</form>
