<?php
include 'db_connect.php'; 

$sql = "SELECT emp_id, emp_name, salary FROM employee";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   
    echo "<table border='1'><tr><th>Employee ID</th><th>Employee Name</th><th>Salary</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["emp_id"] . "</td><td>" . $row["emp_name"] . "</td><td>" . $row["salary"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>
