<?php
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $emp_id = $_POST['emp_id'];
    $emp_name = $_POST['emp_name'];
    $salary = $_POST['salary'];

    $stmt = $conn->prepare("INSERT INTO employee (emp_id, emp_name, salary) VALUES (?, ?, ?)");
    $stmt->bind_param("isd", $emp_id, $emp_name, $salary); 


    if ($stmt->execute()) {
        echo "New employee record inserted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Employee ID: <input type="number" name="emp_id" required><br>
    Employee Name: <input type="text" name="emp_name" required><br>
    Salary: <input type="number" step="0.01" name="salary" required><br>
    <input type="submit" value="Insert">
</form>
