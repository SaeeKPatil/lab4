<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $roll_no = $_POST['roll_no'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone_number = $_POST['phone_number'];

    if ($_POST['password'] !== $_POST['confirm_password']) {
        echo "Passwords do not match.";
    } else {
        $stmt = $conn->prepare("INSERT INTO students (first_name, last_name, roll_no, password, phone_number) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiss", $first_name, $last_name, $roll_no, $password, $phone_number);

        if ($stmt->execute()) {
            echo "Student details inserted successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>

<form method="post" action="">
    First Name: <input type="text" name="first_name" required><br>
    Last Name: <input type="text" name="last_name" required><br>
    Roll No/ID: <input type="number" name="roll_no" required><br>
    Password: <input type="password" name="password" required><br>
    Confirm Password: <input type="password" name="confirm_password" required><br>
    Phone Number: <input type="text" name="phone_number" required><br>
    <input type="submit" value="Insert Student">
</form>
