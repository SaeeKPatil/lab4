<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $roll_no = $_POST['roll_no'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone_number = $_POST['phone_number'];

    $stmt = $conn->prepare("UPDATE students SET first_name = ?, last_name = ?, phone_number = ? WHERE roll_no = ?");
    $stmt->bind_param("sssi", $first_name, $last_name, $phone_number, $roll_no);

    if ($stmt->execute()) {
        echo "Student details updated successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Roll No/ID: <input type="number" name="roll_no" required><br>
    First Name: <input type="text" name="first_name"><br>
    Last Name: <input type="text" name="last_name"><br>
    Phone Number: <input type="text" name="phone_number"><br>
    <input type="submit" value="Update Student">
</form>
