<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $roll_no = $_POST['roll_no'];

    $stmt = $conn->prepare("DELETE FROM students WHERE roll_no = ?");
    $stmt->bind_param("i", $roll_no);

    if ($stmt->execute()) {
        echo "Student record deleted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Roll No/ID: <input type="number" name="roll_no" required><br>
    <input type="submit" value="Delete Student">
</form>
