<?php
include 'db.php';

$sql = "SELECT first_name, last_name, roll_no, phone_number FROM students";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>First Name</th><th>Last Name</th><th>Roll No/ID</th><th>Phone Number</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["first_name"] . "</td><td>" . $row["last_name"] . "</td><td>" . $row["roll_no"] . "</td><td>" . $row["phone_number"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No students found";
}

$conn->close();
?>
