<?php
include 'db.php';

$sql = "SELECT passenger_name, departure_city, arrival_city, flight_date, departure_date, arrival_date, phone_number, email_id FROM passengers";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Passenger Name</th><th>From</th><th>To</th><th>Flight Date</th><th>Departure Date</th><th>Arrival Date</th><th>Phone Number</th><th>Email ID</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["passenger_name"] . "</td><td>" . $row["departure_city"] . "</td><td>" . $row["arrival_city"] . "</td><td>" . $row["flight_date"] . "</td><td>" . $row["departure_date"] . "</td><td>" . $row["arrival_date"] . "</td><td>" . $row["phone_number"] . "</td><td>" . $row["email_id"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No passengers found";
}

$conn->close();
?>
