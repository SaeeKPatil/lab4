<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone_number = $_POST['phone_number'];
    $passenger_name = $_POST['passenger_name'];
    $departure_city = $_POST['departure_city'];
    $arrival_city = $_POST['arrival_city'];
    $flight_date = $_POST['flight_date'];
    $departure_date = $_POST['departure_date'];
    $arrival_date = $_POST['arrival_date'];
    $email_id = $_POST['email_id'];

    $stmt = $conn->prepare("UPDATE passengers SET passenger_name = ?, departure_city = ?, arrival_city = ?, flight_date = ?, departure_date = ?, arrival_date = ?, email_id = ? WHERE phone_number = ?");
    $stmt->bind_param("ssssssss", $passenger_name, $departure_city, $arrival_city, $flight_date, $departure_date, $arrival_date, $email_id, $phone_number);

    if ($stmt->execute()) {
        echo "Passenger details updated successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Phone Number: <input type="text" name="phone_number" required><br>
    Passenger Name: <input type="text" name="passenger_name"><br>
    From: <input type="text" name="departure_city"><br>
    To: <input type="text" name="arrival_city"><br>
    Flight Date: <input type="date" name="flight_date"><br>
    Departure Date: <input type="date" name="departure_date"><br>
    Arrival Date: <input type="date" name="arrival_date"><br>
    Email ID: <input type="email" name="email_id"><br>
    <input type="submit" value="Update Passenger">
</form>
