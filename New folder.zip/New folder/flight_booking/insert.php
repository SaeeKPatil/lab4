<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $passenger_name = $_POST['passenger_name'];
    $departure_city = $_POST['departure_city'];
    $arrival_city = $_POST['arrival_city'];
    $flight_date = $_POST['flight_date'];
    $departure_date = $_POST['departure_date'];
    $arrival_date = $_POST['arrival_date'];
    $phone_number = $_POST['phone_number'];
    $email_id = $_POST['email_id'];

    $stmt = $conn->prepare("INSERT INTO passengers (passenger_name, departure_city, arrival_city, flight_date, departure_date, arrival_date, phone_number, email_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $passenger_name, $departure_city, $arrival_city, $flight_date, $departure_date, $arrival_date, $phone_number, $email_id);

    if ($stmt->execute()) {
        echo "Passenger details inserted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Passenger Name: <input type="text" name="passenger_name" required><br>
    From: <input type="text" name="departure_city" required><br>
    To: <input type="text" name="arrival_city" required><br>
    Flight Date: <input type="date" name="flight_date" required><br>
    Departure Date: <input type="date" name="departure_date" required><br>
    Arrival Date: <input type="date" name="arrival_date" required><br>
    Phone Number: <input type="text" name="phone_number" required><br>
    Email ID: <input type="email" name="email_id" required><br>
    <input type="submit" value="Insert Passenger">
</form>
