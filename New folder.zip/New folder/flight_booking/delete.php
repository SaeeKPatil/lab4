<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone_number = $_POST['phone_number'];

    $stmt = $conn->prepare("DELETE FROM passengers WHERE phone_number = ?");
    $stmt->bind_param("s", $phone_number);

    if ($stmt->execute()) {
        echo "Passenger record deleted successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<form method="post" action="">
    Phone Number: <input type="text" name="phone_number" required><br>
    <input type="submit" value="Delete Passenger">
</form>
